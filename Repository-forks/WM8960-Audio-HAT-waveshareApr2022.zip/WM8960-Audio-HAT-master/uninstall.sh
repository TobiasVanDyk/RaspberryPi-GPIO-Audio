#!/bin/bash

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root (use sudo)" 1>&2
   exit 1
fi

is_Raspberry=$(cat /proc/device-tree/model | awk  '{print $1}')
if [ "x${is_Raspberry}" != "xRaspberry" ] ; then
  echo "Sorry, this drivers only works on raspberry pi"
  exit 1
fi

#sed -i '/dtoverlay=wm8960-soundcard/d' /boot/config.txt

echo "remove alsa configs"
rm -rf  /etc/wm8960-soundcard/ || true

echo "disabled service "
systemctl disable wm8960-soundcard.service 

echo "remove wm8960-soundcard"
rm  /usr/bin/wm8960-soundcard || true
rm  /lib/systemd/system/wm8960-soundcard.service || true
rm  -rf /var/lib/dkms/wm8960-soundcard || true

echo "------------------------------------------------------"
echo "Please reboot your raspberry pi to apply all settings"
echo "Thank you!"
echo "------------------------------------------------------"
